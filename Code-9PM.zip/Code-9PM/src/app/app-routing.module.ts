import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LandingpageComponent } from './landingpage/landingpage.component';
import { MainComponent } from './main/main.component';
import { ErrorPageComponent } from './pages/error-page/error-page.component';


const routes: Routes = [
  { path: '', redirectTo: 'pages/about-us', pathMatch: 'full' },
  { path: 'landingpage', component: LandingpageComponent },
  {
    path: '', component: MainComponent,
    children: [
      { path: 'pages', loadChildren: () => import('../app/pages/pages.module').then(m => m.PagesModule) }
    ]
  },
  { path: '**', component: ErrorPageComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
