import { Injectable } from '@angular/core';
import { ToastrModule, ToastrService } from 'ngx-toastr';
import { Observable, of } from 'rxjs';
import { Product } from '../classes/product';

// get product from Localstorage
let products = JSON.parse(localStorage.getItem("wishlistItem"));

@Injectable({
  providedIn: 'root'
})
export class WishlistService {

  constructor(private _toastr: ToastrService) { }


  // get Products
  getProducts(): Observable<Product[]> {
    let items: Observable<Product[]> = of(products);
    return items;
  }

  // if item is already added in wishlist
  hasProduct(product: Product): boolean {
    let item = products.find(item => item.id === product.id);

    return item !== undefined;
  }

  // add to Wishlist
  addToWishList(product: Product): Product | boolean {
    let item: Product | boolean = false;
    if (this.hasProduct(product)) {
      item = products.find(item => item.id === product.id)
    } else {
      products.push(product);
      this._toastr.success("This product added to wishlist !!");
      localStorage.setItem("wishlistItem", JSON.stringify(products));
    }
    return item;
  }

  // Remove from whislist
  removeFromWhishList(product: Product) {
    if (product === undefined) {
      return false;
    }

    let index = products.indexOf(product);
    products.splice(index, 1);
    localStorage.setItem("wishlistItem", JSON.stringify(products));
  }

}
