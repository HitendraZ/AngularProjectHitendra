import { Injectable } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Observable, of } from 'rxjs';
import { Product } from '../classes/product';
import { CartItem } from '../classes/cart-item';

// get product from Localstorage
let products = JSON.parse(localStorage.getItem("cartItem"));

@Injectable({
  providedIn: 'root'
})
export class CartService {

  constructor(private _toastr: ToastrService) { }

  // get Products
  getProducts(): Observable<Product[]> {
    let items: Observable<Product[]> = of(products);
    return items;
  }


  // Add To Cart
  addToCart(product: Product, quantity: number): CartItem | boolean {
    let item: CartItem | boolean = false;
    // if Product exists
    let hasItem = products.find((items, index) => {
      if (items.product.id == product.id) {
        let qty = products[index].quantity + quantity;
        let stock = 100;

        if (qty != 0 && stock) {
          products[index]["quantity"] = qty;
          this._toastr.success("This product has been added !!");
          localStorage.setItem("cartItem", JSON.stringify(products));
        }
        return true;
      }
    });

    //if product does not exists (add new product here)

    if (!hasItem) {
      item = { product: product, quantity: quantity };
      products.push(item);
      this._toastr.success("This product has been added !!");
      localStorage.setItem("cartItem", JSON.stringify(products));
    }
    return item;
  }

  // Update Cart
  updateCartQuantity(product: Product, quantity: number): CartItem | boolean {
    return products.find((items, index) => {
      if (items.product.id == product.id) {
        let qty = products[index].quantity + quantity;
        let stock = 100;

        if (qty != 0 && stock) {
          products[index]["quantity"] = qty;
          this._toastr.success("This product has been added !!");
          localStorage.setItem("cartItem", JSON.stringify(products));
        }
        return true;
      }
    });
  }

  // Remove from whislist
  removeFromWhishList(product: Product) {
    if (product === undefined) {
      return false;
    }

    let index = products.indexOf(product);
    products.splice(index, 1);
    localStorage.setItem("cartItem", JSON.stringify(products));
  }

  calculateStockCounts(product: CartItem, quantity: number): CartItem | boolean {
    let qty = product.quantity + quantity;
    let stock = product.product.stock;
    if (stock < qty) {
      this._toastr.error("You can n ot add more Items !!");
      return false;
    }

    return true;
  }


}
