export class Global {
    // For localhost
       public static BASE_USER_ENDPOINT = 'https://localhost:44361/api/';
  
    // For Live Server
   // public static BASE_USER_ENDPOINT = '';
  }
  