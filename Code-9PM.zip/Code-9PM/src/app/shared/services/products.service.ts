import { Injectable } from '@angular/core';
import { DataService } from './data.service';
import { ToastrService } from 'ngx-toastr';
import { Observable, of } from 'rxjs';
import { Product } from '../classes/product';
import { Global } from './global';
import 'rxjs/add/operator/map';


// get product from Localstorage
let products = JSON.parse(localStorage.getItem("compareItem"));

@Injectable({
  providedIn: 'root'
})
export class ProductsService {

  currency: string = 'INR';

  constructor(private _dataService: DataService, private _toastr: ToastrService) { }

  private products(): Observable<Product[]> {
    let data = this._dataService.get(Global.BASE_USER_ENDPOINT + "ProductMaster/GetProductList");
    return data;
  }

  // get products 
  getProducts(): Observable<Product[]> {
    return this.products();
  }

  // get product by id
  getProduct(id: number): Observable<Product> {
    return this.products().map(items => items.find((item: Product) => item.id === id));
  }

  // get products by category
  getProductByCategory(category: string): Observable<Product[]> {
    return this.products().map(items =>
      items.filter((item: Product) => {
        if (category == 'all') {
          return true;
        } else {
          return item.category === category;
        }
      })
    );
  }

  // get   compare products
  getCompareProducts(): Observable<Product[]> {
    let items: Observable<Product[]> = of(products);
    return items;
  }

  // if item is already added in wishlist
  hasProduct(product: Product): boolean {
    let item = products.find(item => item.id === product.id);
    return item !== undefined;
  }

  // add to Compare
  addToCompare(product: Product): Product | boolean {
    let item: Product | boolean = false;

    if (this.hasProduct(product)) {
      item = products.find(item => item.id === product.id)
    } else {
      if (products.length < 4) {
        products.push(product);
        localStorage.setItem("compareItem", JSON.stringify(products));
      } else {
        this._toastr.warning("Maximum 4 products must be in compare !!");
      }
    }
    return item;

  }

// Remove from whislist
removeFromWhishList(product: Product) {
  if (product === undefined) {
    return false;
  }

  let index = products.indexOf(product);
  products.splice(index, 1);
  localStorage.setItem("compareItem", JSON.stringify(products));
}

}
