import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-why-we-choose',
  templateUrl: './why-we-choose.component.html',
  styleUrls: ['./why-we-choose.component.scss']
})
export class WhyWeChooseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
