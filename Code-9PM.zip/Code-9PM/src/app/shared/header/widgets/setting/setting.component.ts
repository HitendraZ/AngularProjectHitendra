import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-setting',
  templateUrl: './setting.component.html',
  styleUrls: ['./setting.component.scss']
})
export class SettingComponent implements OnInit {

  constructor(private _translateService: TranslateService) { }

  ngOnInit(): void {
  }

  changeLanguage(lang: string) {
    this._translateService.use(lang);
  }

}
