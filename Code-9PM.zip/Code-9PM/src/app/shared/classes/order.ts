import { CartItem } from './cart-item';


export interface Order {
    shippingDetails?: any;
    product?: CartItem;
    orderId?: any;
    paymentDate?: any,
    expectedDate?: any,
    totalAmount : number;
}