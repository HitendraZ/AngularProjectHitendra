import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-left-sidebar',
  templateUrl: './product-left-sidebar.component.html',
  styleUrls: ['./product-left-sidebar.component.scss']
})
export class ProductLeftSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
