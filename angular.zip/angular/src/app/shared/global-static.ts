export class GlobalStatic {
    public static Admin = 1;
}
