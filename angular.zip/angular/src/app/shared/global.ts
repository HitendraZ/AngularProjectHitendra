export class Global {
// For Localhost 
public static BASE_USER_ENDPOINT = 'https://localhost:44361/api/';



// For Images Path 
public static BASE_IMAGE_PATH = 'https://localhost:44361/images/';

}
