import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})
export class ProfileComponent implements OnInit {
  firstName: string;
  lastName: string;
  emailId: string;
  fullName: string;
  UserDetails: any;

  constructor() { }

  ngOnInit(): void {
    this.UserDetails = JSON.parse(localStorage.getItem("userDetails"));
    this.firstName = this.UserDetails.firstName;
    this.lastName = this.UserDetails.lastName;
    this.emailId = this.UserDetails.email;
    //this.fullName = this.UserDetails.firstName + " " + this.UserDetails.lastName;
    this.fullName = `${this.UserDetails.firstName} ${this.UserDetails.lastName} `;
  }

}
