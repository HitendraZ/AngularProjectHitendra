﻿using BusinessEntities.Mall.RequestDto;
using Repositories.dbContext;
using Repositories.Interface;
using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Repositories.Mall;
using System.Data.SqlClient;
using System.Linq;

namespace Repositories.Implementation
{
    public class SizeMasterRepositories : ISizeMasterRepositories
    {
        private ApplicationDbContext _context;

        public SizeMasterRepositories(ApplicationDbContext context)
        {
            _context = context;
        }

        public long Add(SizeMasterRequest viewModel)
        {
                var obj = _context.Database.ExecuteSqlCommand("Execute InsertSizeMaster @Name,@CreatedBy",
                    new SqlParameter("@Name", viewModel.Name),
                    new SqlParameter("@CreatedBy", viewModel.CreatedBy)
                    );

                return obj;
        }

        public long Update(SizeMasterRequest viewModel)
        {
                var obj = _context.Database.ExecuteSqlCommand("Execute UpdateSizeMaster @Id,@Name,@ModifiedBy",
                    new SqlParameter("@Id", viewModel.Id),
                    new SqlParameter("@Name", viewModel.Name),
                    new SqlParameter("@ModifiedBy", viewModel.ModifiedBy)
                    );

                return obj;
        }

       public long Delete(long Id)
        {
            
                var obj = _context.Database.ExecuteSqlCommand("Execute DeleteSizeMaster @Id,@ModifiedBy",
                    new SqlParameter("@Id", Id),
                    new SqlParameter("@ModifiedBy", 1)
                    );
                return obj;
        }

        public DBSizeMaster GetbyId(long Id)
        {
            DBSizeMaster obj = _context.SizeMasters.FromSql("GetSizeMasterbyId  @Id",
                new SqlParameter("@Id",Id)
                ).FirstOrDefault();

            return obj;
        }

        public IEnumerable<DBSizeMaster> GetAll()
        {
            IEnumerable<DBSizeMaster> obj = _context.SizeMasters.FromSql("GetAllSizeMaster").ToList(); ;
            return obj;
        }
    }
}
