﻿using BusinessEntities.Mall.RequestDto;
using Microsoft.EntityFrameworkCore;
using Repositories.dbContext;
using Repositories.Interface;
using Repositories.Mall;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;

namespace Repositories.Implementation
{
    public class ColorMasterRepositories : IColorMasterRepositories
    {
        private ApplicationDbContext _context;

        public ColorMasterRepositories(ApplicationDbContext context)
        {
            _context = context;
        }

        public long Add(ColorMasterRequest viewModel)
        {
            var obj = _context.Database.ExecuteSqlCommand("Execute InsertColorMaster @Name,@Code,@CreatedBy",
                new SqlParameter("@Name", viewModel.Name),
                new SqlParameter("@Code", viewModel.Code),
                new SqlParameter("@CreatedBy", viewModel.CreatedBy)
                );

            return obj;
        }

        public long Update(ColorMasterRequest viewModel)
        {
            var obj = _context.Database.ExecuteSqlCommand("Execute UpdateColorMaster @Id,@Name,@Code,@ModifiedBy",
                new SqlParameter("@Id", viewModel.Id),
                new SqlParameter("@Name", viewModel.Name),
                 new SqlParameter("@Code", viewModel.Code),
                new SqlParameter("@ModifiedBy", viewModel.ModifiedBy)
                );

            return obj;
        }

        public long Delete(long Id)
        {

            var obj = _context.Database.ExecuteSqlCommand("Execute DeleteColorMaster @Id,@ModifiedBy",
                new SqlParameter("@Id", Id),
                new SqlParameter("@ModifiedBy", 1)
                );
            return obj;
        }

        public DBColorMaster GetbyId(long Id)
        {
            DBColorMaster obj = _context.ColorMasters.FromSql("GetColorMasterbyId  @Id",
                new SqlParameter("@Id", Id)
                ).FirstOrDefault();

            return obj;
        }

        public IEnumerable<DBColorMaster> GetAll()
        {
            IEnumerable<DBColorMaster> obj = _context.ColorMasters.FromSql("GetAllColorMaster").ToList(); ;
            return obj;
        }
    }
}
