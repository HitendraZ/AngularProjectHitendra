﻿using BusinessEntities.Mall.Master.RequestDto;
using Microsoft.EntityFrameworkCore;
using Repositories.dbContext;
using Repositories.Interface;
using Repositories.Mall;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;

namespace Repositories.Implementation
{
    public class UserTypeRepository : IUserTypeRepository
    {
        protected ApplicationDbContext _Context;
        public UserTypeRepository(ApplicationDbContext context)
        {
            _Context = context;
        }

        public long Add(UserTypeRequest viewModel)
        {
                var lst = _Context.Database.ExecuteSqlCommand(" EXECUTE  InsertUserType @Name,@CreatedBy",
                     new SqlParameter("@Name", viewModel.Name),
                     new SqlParameter("@CreatedBy", viewModel.CreatedBy)
                 );
                return lst;
        }
        public long Update(UserTypeRequest viewModel)
        {
                var lst = _Context.Database.ExecuteSqlCommand(" EXECUTE  UpdateUserType @Id,@Name,@ModifiedBy,@ModifiedOn",
                     new SqlParameter("@Id", viewModel.Id),
                     new SqlParameter("@Name", viewModel.Name),
                     new SqlParameter("@ModifiedBy", viewModel.ModifiedBy),
                     new SqlParameter("@ModifiedOn", viewModel.ModifiedOn)
                 );
                return lst;
        }
        public long Delete(int Id)
        {
            var lst = _Context.Database.ExecuteSqlCommand(" EXECUTE  DeleteUserType @Id",
                    new SqlParameter("@Id", Id)
                );

            return lst;
        }
        public IEnumerable<DBUserType> GetAll()
        {
            List<DBUserType> lst = _Context.UserTypes.FromSql("GetAllUserType").ToList();
            return lst;
        }
        public DBUserType GetbyId(int Id)
        {
            DBUserType lst = _Context.UserTypes.FromSql("GetUserTypebyId @Id",
             new SqlParameter("@Id", Id)
             ).FirstOrDefault();
            return lst;
        }
    }
}
