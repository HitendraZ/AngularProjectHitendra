﻿using BusinessEntities.Mall.Master.RequestDto;
using Microsoft.EntityFrameworkCore;
using Repositories.dbContext;
using Repositories.Interface;
using Repositories.Mall;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;

namespace Repositories.Implementation
{
    public  class ContactUsRepository : IContactUsRepository
    {
        protected ApplicationDbContext _Context;
        public ContactUsRepository(ApplicationDbContext context)
        {
            _Context = context;
        }

        public long Add(ContactUsRequest viewModel)
        {
                var lst = _Context.Database.ExecuteSqlCommand(" EXECUTE  InsertContactUs @FirstName,@LastName,@Email,@PhoneNumber,@Message,@CreatedBy",
                     new SqlParameter("@FirstName", viewModel.FirstName),
                     new SqlParameter("@LastName", viewModel.LastName),
                     new SqlParameter("@Email", viewModel.EmailId),
                     new SqlParameter("@PhoneNumber", viewModel.MobileNo),
                     new SqlParameter("@Message", viewModel.Message),
                     new SqlParameter("@CreatedBy", viewModel.CreatedBy)
                 );
                return lst;
        }
        public long Delete(int Id)
        {
            var lst = _Context.Database.ExecuteSqlCommand(" EXECUTE  DeleteContactUs @ContactId",
                    new SqlParameter("@ContactId", Id)
                );

            return lst;
        }
        public IEnumerable<DBContactUs> GetAll()
        {
            List<DBContactUs> lst = _Context.ContactUss.FromSql("GetAllContactUs").ToList();
            return lst;
        }
    }
}
