﻿using BusinessEntities.Mall.Common;
using Microsoft.EntityFrameworkCore;
using Repositories.dbContext;
using Repositories.Interface;
using System;
using System.Data.SqlClient;

namespace Repositories.Implementation
{
    public class ExceptionLogRepositories : IExceptionLogRepositories
    {
        private ApplicationDbContext _context;
        public ExceptionLogRepositories(ApplicationDbContext context)
        {
            _context = context;
        }

        public long Add(LogEntryRequest viewModel)
        {
            try
            {
                var obj = _context.Database.ExecuteSqlCommand("Execute InsertExceptionLog @Date,@Message,@Type,@Source,@RequestPath",
                    new SqlParameter("@Date", viewModel.Date),
                    new SqlParameter("@Message", viewModel.Message),
                    new SqlParameter("@Type", viewModel.Type),
                    new SqlParameter("@Source", viewModel.Source),
                    new SqlParameter("@RequestPath", viewModel.RequestPath)
                    );

                return obj;
            }
            catch (Exception ex)
            {

            }
            return 0;
        }
    }
}
