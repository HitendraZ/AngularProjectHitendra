﻿using BusinessEntities.Mall.Master.RequestDto;
using Microsoft.EntityFrameworkCore;
using Repositories.dbContext;
using Repositories.Interface;
using Repositories.Mall;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;

namespace Repositories.Implementation
{
    public class PaymentMasterRepository : IPaymentMasterRepository
    {
        protected ApplicationDbContext _Context;
        public PaymentMasterRepository(ApplicationDbContext context)
        {
            _Context = context;
        }
        
        public DBBillingDetails AddBillingDetails(BillingDetailsRequest viewModel)
        {
            DBBillingDetails lst = _Context.BillingDetails.FromSql("InsertBillingDetails @CustomerId,@FirstName,@LastName,@Phone,@EmailId,@CountryId,@Address,@City,@State,@PostalCode,@CreatedBy",
                 new SqlParameter("@CustomerId", viewModel.customerId==null?0: viewModel.customerId),
                 new SqlParameter("@firstname", viewModel.firstname),
                 new SqlParameter("@lastname", viewModel.lastname),
                 new SqlParameter("@phone", viewModel.phone),
                 new SqlParameter("@EmailId", viewModel.email),
                 new SqlParameter("@address", viewModel.address),
                 new SqlParameter("@CountryId", viewModel.country),
                 new SqlParameter("@City", viewModel.town),
                 new SqlParameter("@state", viewModel.state),
                 new SqlParameter("@postalcode", viewModel.postalcode),
                 new SqlParameter("@CreatedBy", viewModel.CreatedBy)
             ).FirstOrDefault();

            return lst;
        }
        public DBPurchaseItem AddPurchaseItem(PurchaseItemRequest viewModel)
        {
            DBPurchaseItem lst = _Context.PurchaseItems.FromSql("InsertPurchaseItemMaster @ProductId,@Price,@Discount,@Quantity,@Size,@Color,@CreatedBy",
                 new SqlParameter("@ProductId", viewModel.ProductId == null ? 0 : viewModel.ProductId),
                 new SqlParameter("@Price", viewModel.Price),
                 new SqlParameter("@Discount", viewModel.Discount),
                 new SqlParameter("@Quantity", viewModel.Quantity),
                 new SqlParameter("@Size", viewModel.Size),
                 new SqlParameter("@Color", viewModel.Color),
                 new SqlParameter("@CreatedBy", viewModel.CreatedBy)
             ).FirstOrDefault();

            return lst;
        }
        public long AddBillMaster(BillMasterRequest viewModel)
        {
            var lst = _Context.Database.ExecuteSqlCommand(" EXECUTE InsertBillMaster @PurchaseId,@BillingDetailsId",
                     new SqlParameter("@PurchaseId", viewModel.PurchaseId == null ? 0 : viewModel.PurchaseId),
                     new SqlParameter("@BillingDetailsId", viewModel.BillingDetailsId)
                 );

            return lst;
        }
        public DBDoPaymentMaster AddPaymentMaster(DoPaymentMasterRequest viewModel)
        {
            DBDoPaymentMaster lst = _Context.DoPaymentMasters.FromSql("InsertPaymentMaster @BillDetailId,@SubTotalAmount,@ShippingAmount,@PaymentTypeId,@PaymentStatus,@CreatedBy",
                     new SqlParameter("@BillDetailId", viewModel.BillDetailId == null ? 0 : viewModel.BillDetailId),
                     new SqlParameter("@SubTotalAmount", viewModel.SubTotalAmount),
                     new SqlParameter("@ShippingAmount", viewModel.ShippingAmount),
                     new SqlParameter("@PaymentTypeId", viewModel.PaymentTypeId),
                     new SqlParameter("@PaymentStatus", viewModel.PaymentStatus),
                     new SqlParameter("@CreatedBy", viewModel.CreatedBy)
                 ).FirstOrDefault();

            return lst;
        }
        public DBOnlinePaymentMaster SaveOnlinePayment(OnlinePaymentMasterRequest viewModel)
        {
            DBOnlinePaymentMaster lst = _Context.OnlinePaymentMaster.FromSql("InsertOnlinePaymentMaster @PaymentId,@tokenId,@transactionId,@country,@brand,@exp_month,@exp_year,@cvc_check,@Email,@status,@description,@amount,@CreatedBy",
                     new SqlParameter("@PaymentId", viewModel.PaymentId),
                     new SqlParameter("@tokenId", viewModel.tokenId),
                     new SqlParameter("@transactionId", viewModel.transactionId),
                     new SqlParameter("@country", viewModel.country),
                     new SqlParameter("@brand", viewModel.brand),
                     new SqlParameter("@exp_month", viewModel.exp_month),
                     new SqlParameter("@exp_year", viewModel.exp_year),
                     new SqlParameter("@cvc_check", viewModel.cvc_check),
                     new SqlParameter("@Email", viewModel.Email),
                     new SqlParameter("@status", viewModel.status),
                     new SqlParameter("@description", viewModel.description),
                     new SqlParameter("@amount", viewModel.amount),
                     new SqlParameter("@CreatedBy", viewModel.CreatedBy)
                 ).FirstOrDefault();

            return lst;
        }
        //Report Section Here
        public IEnumerable<DBReportManageOrder> GetReportManageOrder()
        {
            List<DBReportManageOrder> lst = _Context.ReportManageOrder.FromSql("Proc_ReportManageOrder").ToList();
            return lst;
        }
        public IEnumerable<DBReportTransactionDetails> GetReportTransactionDetails()
        {
            List<DBReportTransactionDetails> lst = _Context.ReportTransactionDetails.FromSql("Proc_ReportTransactionDetails").ToList();
            return lst;
        }
        public IEnumerable<DBReportManageOrder> GetReportCashOnDelivery()
        {
            List<DBReportManageOrder> lst = _Context.ReportManageOrder.FromSql("Proc_ReportCashOnDelivery").ToList();
            return lst;
        }
        public IEnumerable<DBReportManageOrder> GetReportInvoiceList()
        {
            List<DBReportManageOrder> lst = _Context.ReportManageOrder.FromSql("Proc_ReportInvoiceList").ToList();
            return lst;
        }
        public IEnumerable<DBReportNetFigure> GetReportNetFigure()
        {
            List<DBReportNetFigure> lst = _Context.ReportNetFigure.FromSql("Proc_ReportNetFigure").ToList();
            return lst;
        }
        public IEnumerable<DBChartOrderStatus> GetChartOrderStatus()
        {
            List<DBChartOrderStatus> lst = _Context.ChartOrderStatus.FromSql("Proc_ChartOrderStatus").ToList();
            return lst;
        }
        public IEnumerable<DBChartSalesDataPaymentTypeWise> GetChartSalesDataPaymentTypeWise()
        {
            List<DBChartSalesDataPaymentTypeWise> lst = _Context.ChartSalesDataPaymentTypeWise.FromSql("Proc_ChartSalesDataPaymentTypeWise").ToList();
            return lst;
        }
        public IEnumerable<DBChartUserGrowth> GetChartUserGrowth()
        {
            List<DBChartUserGrowth> lst = _Context.ChartUserGrowths.FromSql("Proc_ChartUserGrowth").ToList();
            return lst;
        }
    }
}
