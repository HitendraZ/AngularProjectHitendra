﻿using BusinessEntities.Mall.RequestDto;
using Microsoft.EntityFrameworkCore;
using Repositories.dbContext;
using Repositories.Interface;
using Repositories.Mall;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;

namespace Repositories.Implementation
{
    public class TagMasterRepositories : ITagMasterRepositories
    {
        private ApplicationDbContext _context;

        public TagMasterRepositories(ApplicationDbContext context)
        {
            _context = context;
        }

        public long Add(TagMasterRequest viewModel)
        {
            try
            {
                var obj = _context.Database.ExecuteSqlCommand("Execute InsertTagMaster @Name,@CreatedBy",
                    new SqlParameter("@Name", viewModel.Name),
                    new SqlParameter("@CreatedBy", viewModel.CreatedBy)
                    );

                return obj;
            }
            catch (Exception ex)
            {

            }
            return 0;
        }

        public long Update(TagMasterRequest viewModel)
        {
            try
            {
                var obj = _context.Database.ExecuteSqlCommand("Execute UpdateTagMaster @Id,@Name,@ModifiedBy",
                    new SqlParameter("@Id", viewModel.Id),
                    new SqlParameter("@Name", viewModel.Name),
                    new SqlParameter("@ModifiedBy", viewModel.ModifiedBy)
                    );

                return obj;
            }
            catch (Exception ex)
            {

            }
            return 0;
        }

        public long Delete(long Id)
        {
            try
            {
                var obj = _context.Database.ExecuteSqlCommand("Execute DeleteTagMaster @Id,@ModifiedBy",
                    new SqlParameter("@Id", Id),
                    new SqlParameter("@ModifiedBy", 1)
                    );
                return obj;
            }
            catch (Exception ex)
            {

            }
            return 0;
        }

        public DBTagMaster GetbyId(long Id)
        {
            DBTagMaster obj = _context.TagMasters.FromSql("GetTagMasterbyId  @Id",
                new SqlParameter("@Id", Id)
                ).FirstOrDefault();

            return obj;
        }

        public IEnumerable<DBTagMaster> GetAll()
        {
            IEnumerable<DBTagMaster> obj = _context.TagMasters.FromSql("GetAllTagMaster").AsEnumerable(); ;
            return obj;
        }
    }
}
