﻿namespace Repositories.Mall
{
    public class DBChartSalesDataPaymentTypeWise
    {
        public string PaymentType { get; set; }
        public string Date { get; set; }
        public int counts { get; set; }
    }
}
