﻿namespace Repositories.Mall
{
    public class DBChartUserGrowth
    {
        public string UserType { get; set; }
        public string Date { get; set; }
        public int counts { get; set; }
    }
}
