﻿namespace Repositories.Mall
{
    public class DBProductListSizes
    {
        public int ProductId { get; set; }
        public string Name { get; set; }
    }
}
