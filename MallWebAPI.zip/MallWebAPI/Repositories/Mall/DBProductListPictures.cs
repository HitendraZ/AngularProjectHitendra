﻿namespace Repositories.Mall
{
    public class DBProductListPictures
    {
        public int ProductId { get; set; }
        public string Name { get; set; }
    }
}
