﻿namespace Repositories.Mall
{
    public class DBChartOrderStatus
    {
        public string OrderStatus { get; set; }
        public string Date { get; set; }
        public int counts { get; set; }
    }
}
