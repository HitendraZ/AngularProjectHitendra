﻿namespace Repositories.Mall
{
    public class DBProductListTags
    {
        public int ProductId { get; set; }
        public string Name { get; set; }
    }
}
