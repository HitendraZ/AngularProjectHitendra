﻿using Microsoft.EntityFrameworkCore;
using Repositories.Mall;

namespace Repositories.dbContext
{
    public class ApplicationDbContext : DbContext
    {

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {

        }

        public DbQuery<DBSizeMaster> SizeMasters { get; set; }
        public DbQuery<DBTagMaster> TagMasters { get; set; }
        public DbQuery<DBColorMaster> ColorMasters { get; set; }

        public DbQuery<DBUserMaster> UserMasters { get; set; }
        public DbQuery<DBBrandLogo> BrandLogos { get; set; }
        public DbQuery<DBCategoryMaster> CategoryMasters { get; set; }
        public DbQuery<DBUserType> UserTypes { get; set; }
        public DbQuery<DBContactUs> ContactUss { get; set; }
        public DbQuery<DBCustomerMaster> CustomerMasters { get; set; }
        public DbQuery<DBLogin> Logins { get; set; }
        public DbQuery<DBProductMaster> ProductMasters { get; set; }
        public DbQuery<DBProductPictureMapping> ProductPictureMappings { get; set; }

        public DbQuery<DBProductList> ProductLists { get; set; }
        public DbQuery<DBProductListColors> ProductListColors { get; set; }
        public DbQuery<DBProductListTags> ProductListTags { get; set; }
        public DbQuery<DBProductListSizes> ProductListSizes { get; set; }
        public DbQuery<DBProductListPictures> ProductListPictures { get; set; }
        public DbQuery<DBProductListVariants> ProductListVariants { get; set; }

        public DbQuery<DBBillingDetails> BillingDetails { get; set; }
        public DbQuery<DBPurchaseItem> PurchaseItems { get; set; }
        public DbQuery<DBDoPaymentMaster> DoPaymentMasters { get; set; }
        public DbQuery<DBOnlinePaymentMaster> OnlinePaymentMaster { get; set; }

        //For Report and Chart
        public DbQuery<DBReportManageOrder> ReportManageOrder { get; set; }
        public DbQuery<DBReportTransactionDetails> ReportTransactionDetails { get; set; }
        public DbQuery<DBReportNetFigure> ReportNetFigure { get; set; }
        public DbQuery<DBChartOrderStatus> ChartOrderStatus { get; set; }
        public DbQuery<DBChartSalesDataPaymentTypeWise> ChartSalesDataPaymentTypeWise { get; set; }
        public DbQuery<DBChartUserGrowth> ChartUserGrowths { get; set; }

    }
}
