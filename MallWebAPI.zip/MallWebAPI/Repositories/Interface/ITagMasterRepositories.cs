﻿using BusinessEntities.Mall.RequestDto;
using Repositories.Mall;
using System.Collections.Generic;

namespace Repositories.Interface
{
    public interface ITagMasterRepositories
    {
        long Add(TagMasterRequest viewModel);
        long Update(TagMasterRequest viewModel);
        long Delete(long Id);
        DBTagMaster GetbyId(long Id);
        IEnumerable<DBTagMaster> GetAll();
    }
}
