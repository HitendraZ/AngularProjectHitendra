﻿using BusinessEntities.Mall.Master.RequestDto;
using Repositories.Mall;
using System.Collections.Generic;

namespace Repositories.Interface
{
    public interface IPaymentMasterRepository
    {
        DBBillingDetails AddBillingDetails(BillingDetailsRequest viewModel);
        DBPurchaseItem AddPurchaseItem(PurchaseItemRequest viewModel);
        long AddBillMaster(BillMasterRequest viewModel);
        DBDoPaymentMaster AddPaymentMaster(DoPaymentMasterRequest viewModel);
        DBOnlinePaymentMaster SaveOnlinePayment(OnlinePaymentMasterRequest viewModel);
        //Report Section Here
        IEnumerable<DBReportManageOrder> GetReportManageOrder();
        IEnumerable<DBReportTransactionDetails> GetReportTransactionDetails();
        IEnumerable<DBReportManageOrder> GetReportCashOnDelivery();
        IEnumerable<DBReportManageOrder> GetReportInvoiceList();
        IEnumerable<DBReportNetFigure> GetReportNetFigure();
        //Chart Section Here
        IEnumerable<DBChartOrderStatus> GetChartOrderStatus();
        IEnumerable<DBChartSalesDataPaymentTypeWise> GetChartSalesDataPaymentTypeWise();
        IEnumerable<DBChartUserGrowth> GetChartUserGrowth();
    }
}
