﻿using Repositories.Mall;
using System.Collections.Generic;
using BusinessEntities.Mall.RequestDto;

namespace Repositories.Interface
{
    public interface IColorMasterRepositories
    {
        long Add(ColorMasterRequest viewModel);
        long Update(ColorMasterRequest viewModel);
        long Delete(long Id);
        DBColorMaster GetbyId(long Id);
        IEnumerable<DBColorMaster> GetAll();
    }
}
