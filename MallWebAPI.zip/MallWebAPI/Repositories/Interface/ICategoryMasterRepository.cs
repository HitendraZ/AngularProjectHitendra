﻿using BusinessEntities.Mall.Master.RequestDto;
using Repositories.Mall;
using System;
using System.Collections.Generic;
using System.Text;

namespace Repositories.Interface
{
    public interface ICategoryMasterRepository
    {
        long Add(CategoryMasterRequest viewModel);
        long Update(CategoryMasterRequest viewModel);
        long Delete(int ID);
        DBCategoryMaster GetbyId(int TypeId);
        IEnumerable<DBCategoryMaster> GetAll();
    }
}
