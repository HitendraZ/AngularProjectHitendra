﻿using BusinessEntities.Mall.Common;

namespace Repositories.Interface
{
    public interface IExceptionLogRepositories
    {
        long Add(LogEntryRequest viewModel);
    }
}
