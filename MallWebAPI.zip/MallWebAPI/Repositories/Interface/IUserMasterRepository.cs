﻿using Repositories.Mall;
using System.Collections.Generic;
using BusinessEntities.Mall.Master.RequestDto;

namespace Repositories.Interface
{
    public interface IUserMasterRepository
    {
        long Add(UserMasterRequest viewModel);
        long UpdateUser(UserMasterRequest viewModel);
        long DeleteUser(int ID);
        DBUserMaster GetUserbyId(int Id);
        IEnumerable<DBUserMaster> GetAllUser();
        DBLogin Login(LoginRequest viewModel);
    }
}
