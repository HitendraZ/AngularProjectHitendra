﻿namespace BusinessEntities.Mall.Master.ResponseDto
{
    public class ProductListColorsResponse
    {
        public int ProductId { get; set; }
        public string Name { get; set; }
    }
}
