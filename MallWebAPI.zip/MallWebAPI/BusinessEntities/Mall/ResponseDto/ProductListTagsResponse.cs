﻿namespace BusinessEntities.Mall.Master.ResponseDto
{
    public class ProductListTagsResponse
    {
        public int ProductId { get; set; }
        public string Name { get; set; }
    }
}
