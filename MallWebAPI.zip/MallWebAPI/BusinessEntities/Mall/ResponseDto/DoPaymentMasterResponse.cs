﻿namespace BusinessEntities.Mall.Master.ResponseDto
{
    public class DoPaymentMasterResponse
    {
        public int Id { get; set; }
        public int BillDetailId { get; set; }
        public string SubTotalAmount { get; set; }
        public string ShippingAmount { get; set; }
        public int PaymentTypeId { get; set; }
        public int PaymentStatus { get; set; }
        public string OrderId { get; set; }
        public string PaymentDate { get; set; }
        public string Expecteddate { get; set; }
    }
}
