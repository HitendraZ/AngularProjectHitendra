﻿namespace BusinessEntities.Mall.Master.ResponseDto
{
    public class BrandLogoResponse : BaseResponse
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string ImagePath { get; set; }
    }
}
