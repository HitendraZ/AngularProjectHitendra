﻿namespace BusinessEntities.Mall.Master.ResponseDto
{
    public class ReportNetFigureResponse
    {
        public decimal Orders { get; set; }
        public decimal ShippingAmount { get; set; }
        public decimal CashOnDelivery { get; set; }
        public decimal Cancelled { get; set; }
    }
}
