﻿namespace BusinessEntities.Mall.ResponseDto
{
    public class SizeMasterResponse : BaseResponse
    {
        public int Id { get; set; }
        public string Name { get; set; }

        //public string Email { get; set; }
        //public string MobileNo { get; set; }
        //public string fullName { get; set; }
    }
}
