﻿namespace BusinessEntities.Mall.ResponseDto
{
    public class TagMasterResponse :BaseResponse
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
