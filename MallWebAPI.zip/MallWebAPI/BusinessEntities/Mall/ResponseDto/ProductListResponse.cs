﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace BusinessEntities.Mall.Master.ResponseDto
{
    public class ProductListResponse
    {
        public int id { get; set; }
        public string name { get; set; }
        public decimal price { get; set; }
        public decimal salePrice { get; set; }
        public int discount { get; set; }
        public string shortDetails { get; set; }
        public string description { get; set; }
        public int stock { get; set; }
        public int isNew { get; set; }
        public int isSale { get; set; }
        public string category { get; set; }
        [NotMapped]
        public List<string> pictures { get; set; }
        [NotMapped]
        public List<string> colors { get; set; }
        [NotMapped]
        public List<string> size { get; set; }
        [NotMapped]
        public List<string> tags { get; set; }
        [NotMapped]
        public List<Variant> variants { get; set; }
    }
    public class Variant
    {
        public string color { get; set; }
        public string images { get; set; }
    }
}
