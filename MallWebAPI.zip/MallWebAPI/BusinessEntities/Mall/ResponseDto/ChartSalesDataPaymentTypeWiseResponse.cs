﻿namespace BusinessEntities.Mall.Master.ResponseDto
{
    public class ChartSalesDataPaymentTypeWiseResponse
    {
        public string PaymentType { get; set; }
        public string Date { get; set; }
        public int counts { get; set; }
    }
}
