﻿namespace BusinessEntities.Mall.Master.RequestDto
{
    public class ContactUsRequest : BaseRequest
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string MobileNo { get; set; }
        public string EmailId { get; set; }
        public string Message { get; set; }
    }
}
