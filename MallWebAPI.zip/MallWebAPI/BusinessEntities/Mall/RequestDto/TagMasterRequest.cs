﻿namespace BusinessEntities.Mall.RequestDto
{
    public class TagMasterRequest : BaseRequest
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
