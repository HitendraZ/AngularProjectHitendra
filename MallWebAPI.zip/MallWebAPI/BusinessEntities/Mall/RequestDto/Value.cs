﻿namespace BusinessEntities.Mall.Master.RequestDto
{
    public class Value
    {
        public int Id { get; set; }
    }
}
