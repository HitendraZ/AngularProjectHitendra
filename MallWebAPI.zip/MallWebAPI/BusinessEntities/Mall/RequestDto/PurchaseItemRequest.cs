﻿namespace BusinessEntities.Mall.Master.RequestDto
{
    public class PurchaseItemRequest:BaseRequest
    {
        public int Id { get; set; }
        public int? ProductId { get; set; }
        public string Price { get; set; }
        public string Discount { get; set; }
        public string Quantity { get; set; }
        public string Size { get; set; }
        public string Color { get; set; }
    }
}
