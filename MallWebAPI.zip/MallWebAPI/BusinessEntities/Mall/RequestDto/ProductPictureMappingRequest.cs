﻿namespace BusinessEntities.Mall.Master.RequestDto
{
    public class ProductPictureMappingRequest:BaseRequest
    {
        public int Id { get; set; }
        public int ProductId { get; set; }
        public string PictureName { get; set; }
        public string PicturePath { get; set; }
        public int IsDelete { get; set; }
    }
}
