﻿namespace BusinessEntities.Mall.RequestDto
{
    public class SizeMasterRequest : BaseRequest
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
