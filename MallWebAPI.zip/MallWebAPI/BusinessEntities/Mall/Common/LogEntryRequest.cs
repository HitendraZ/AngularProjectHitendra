﻿using System;

namespace BusinessEntities.Mall.Common
{
    public class LogEntryRequest
    {
        public DateTime Date { get; set; }
        public string Message { get; set; }
        public string Type { get; set; }
        public string Source { get; set; }
        public string RequestPath { get; set; }
    }
}
