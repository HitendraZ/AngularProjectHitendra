﻿using BusinessEntities.Mall.Common;
using BusinessEntities.Mall.Master.RequestDto;
using BusinessEntities.Mall.Master.ResponseDto;
using System.Collections.Generic;

namespace BusinessService.Interface
{
    public interface IUserTypeService
    {
        ResultDto<long> Add(UserTypeRequest viewModel);
        ResultDto<long> Update(UserTypeRequest viewModel);
        ResultDto<long> Delete(int ID);
        ResultDto<UserTypeResponse> GetbyId(int TypeId);
        ResultDto<IEnumerable<UserTypeResponse>> GetAll();
    }
}
