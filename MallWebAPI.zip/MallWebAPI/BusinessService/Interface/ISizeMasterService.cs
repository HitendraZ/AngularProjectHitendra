﻿using BusinessEntities.Mall.Common;
using BusinessEntities.Mall.RequestDto;
using BusinessEntities.Mall.ResponseDto;
using System.Collections.Generic;

namespace BusinessService.Interface
{
    public interface ISizeMasterService
    {
        ResultDto<long> Add(SizeMasterRequest viewModel);
        ResultDto<long> Update(SizeMasterRequest viewModel);
        ResultDto<long> Delete(long Id);
        ResultDto<SizeMasterResponse> GetbyId(long Id);
        ResultDto<IEnumerable<SizeMasterResponse>> GetAll();
    }
}
