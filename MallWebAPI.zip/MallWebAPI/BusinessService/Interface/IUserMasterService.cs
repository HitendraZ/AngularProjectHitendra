﻿using BusinessEntities.Mall.Common;
using BusinessEntities.Mall.Master.RequestDto;
using BusinessEntities.Mall.Master.ResponseDto;
using System.Collections.Generic;

namespace BusinessService.Interface
{
    public interface IUserMasterService
    {
        ResultDto<long> Add(UserMasterRequest viewModel);
        ResultDto<long> UpdateUser(UserMasterRequest viewModel);
        ResultDto<long> DeleteUser(int ID);
        ResultDto<UserMasterResponse> GetUserbyId(int TypeId);
        ResultDto<IEnumerable<UserMasterResponse>> GetAllUser();
        ResultDto<LoginResponse> Login(LoginRequest viewModel);
    }
}

