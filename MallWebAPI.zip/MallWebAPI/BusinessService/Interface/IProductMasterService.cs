﻿using BusinessEntities.Mall.Common;
using BusinessEntities.Mall.Master.RequestDto;
using BusinessEntities.Mall.Master.ResponseDto;
using System.Collections.Generic;

namespace BusinessService.Interface
{
   public interface IProductMasterService
    {
        ResultDto<ProductMasterResponse> Add(ProductMasterRequest viewModel);
        ResultDto<ProductMasterResponse> Update(ProductMasterRequest viewModel);
        ResultDto<long> Delete(int ID);
        ResultDto<ProductMasterResponse> GetbyId(int TypeId);
        ResultDto<IEnumerable<ProductListPicturesResponse>> GetProductPicturebyId(int Id);
        ResultDto<IEnumerable<ProductMasterResponse>> GetAll();
        ResultDto<long> AddImageMapping(ProductPictureMappingRequest viewModel);
        //For forntend data
        //ResultDto<IEnumerable<ProductListResponse>> GetProductList();
        IEnumerable<ProductListResponse> GetProductList();
        ResultDto<IEnumerable<ProductListColorsResponse>> GetProductcolorsList();
        ResultDto<IEnumerable<ProductListPicturesResponse>> GetProductPicturesList();
        ResultDto<IEnumerable<ProductListSizesResponse>> GetProductSizesList();
        ResultDto<IEnumerable<ProductListTagsResponse>> GetProductTagsList();
        ResultDto<IEnumerable<ProductListVariantsResponse>> GetProductVariantsList();
    }
}
