﻿using BusinessEntities.Mall.Common;
using BusinessEntities.Mall.RequestDto;
using BusinessEntities.Mall.ResponseDto;
using System.Collections.Generic;

namespace BusinessService.Interface
{
    public interface IColorMasterService
    {
        ResultDto<long> Add(ColorMasterRequest viewModel);
        ResultDto<long> Update(ColorMasterRequest viewModel);
        ResultDto<long> Delete(long Id);
        ResultDto<ColorMasterResponse> GetbyId(long Id);
        ResultDto<IEnumerable<ColorMasterResponse>> GetAll();
    }
}
