﻿using BusinessEntities.Mall.Common;
using BusinessEntities.Mall.Master.RequestDto;
using BusinessEntities.Mall.Master.ResponseDto;
using System.Collections.Generic;

namespace BusinessService.Interface
{
    public interface IContactUsService
    {
        ResultDto<long> Add(ContactUsRequest viewModel);
        ResultDto<long> Delete(int ID);
        ResultDto<IEnumerable<ContactUsResponse>> GetAll();
    }
}
