﻿using BusinessEntities.Mall.Common;
using BusinessService.Interface;
using Repositories.Interface;

namespace BusinessService.Implementation
{
    public class ExceptionLogService : IExceptionLogService
    {
        private readonly IExceptionLogRepositories _iExceptionLogRepositories;

        public ExceptionLogService(IExceptionLogRepositories repository)
        {
            _iExceptionLogRepositories = repository;
        }

        public long Add(LogEntryRequest viewModel)
        {
            var res = _iExceptionLogRepositories.Add(viewModel);
            return res;
        }
    }
}
