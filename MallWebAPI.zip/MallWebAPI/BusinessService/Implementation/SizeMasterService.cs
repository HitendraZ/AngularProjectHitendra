﻿using AutoMapper;
using BusinessEntities.Mall.Common;
using BusinessEntities.Mall.RequestDto;
using BusinessEntities.Mall.ResponseDto;
using BusinessService.Interface;
using Repositories.Interface;
using Repositories.Mall;
using System.Collections.Generic;

namespace BusinessService.Implementation
{
    public class SizeMasterService : ISizeMasterService
    {
        private IMapper _mapper;
        private readonly ISizeMasterRepositories _iSizeMasterRepositories;

        public SizeMasterService(ISizeMasterRepositories repository, IMapper mapper)
        {
            _iSizeMasterRepositories = repository;
            _mapper = mapper;
        }

        public ResultDto<long> Add(SizeMasterRequest viewModel)
        {
            var res = new ResultDto<long>()
            {
                IsSuccess = false,
                Data = 0,
                Errors = new List<string>()
            };

            var response = _iSizeMasterRepositories.Add(viewModel);
            if (response>0)
            {
                res.IsSuccess = true;
                res.Data = response;
            }
            else
            {
                res.Errors.Add("Size Name Already Exists !!");
            }
            return res;
        }
        public ResultDto<long> Update(SizeMasterRequest viewModel)
        {
            var res = new ResultDto<long>()
            {
                IsSuccess = false,
                Data = 0,
                Errors = new List<string>()
            };

            var response = _iSizeMasterRepositories.Update(viewModel);
            if (response > 0)
            {
                res.IsSuccess = true;
                res.Data = response;
            }
            else
            {
                res.Errors.Add("Size Name Already Exists !!");
            }
            return res;
        }
        public ResultDto<long> Delete(long Id)
        {
            var res = new ResultDto<long>()
            {
                IsSuccess = false,
                Data = 0,
                Errors = new List<string>()
            };

            var response = _iSizeMasterRepositories.Delete(Id);
            if (response > 0)
            {
                res.IsSuccess = true;
                res.Data = response;
            }
            else
            {
                res.Errors.Add("Record not exists !!");
            }
            return res;
        }
        public ResultDto<SizeMasterResponse> GetbyId(long Id)
        {
            var res = new ResultDto<SizeMasterResponse>()
            {
                IsSuccess = false,
                Data = null,
                Errors = new List<string>()
            };
            var response = _iSizeMasterRepositories.GetbyId(Id);

            //Mapper.Initialize(config =>
            //{
            //    config.CreateMap<DBSizeMaster, SizeMasterResponse>()
            //    .ForMember(dest => dest.Email, act => act.Ignore())
            //    .ForMember(dest => dest.MobileNo, act => act.Ignore())
            //    .ForMember(user => user.fullName, map => map.MapFrom(f => f.Name + '-' + f.Status));
            //});

            if (response !=null)
            {
                res.IsSuccess = true;
                //res.Data = Mapper.Map<DBSizeMaster, SizeMasterResponse>(response);
                res.Data = _mapper.Map<DBSizeMaster, SizeMasterResponse>(response);
            }
            else
            {
                res.Errors.Add("Something went wrong !!");
            }
            return res;
        }
        public ResultDto<IEnumerable<SizeMasterResponse>> GetAll()
        {
            var res = new ResultDto<IEnumerable<SizeMasterResponse>>()
            {
                IsSuccess = false,
                Data = null,
                Errors = new List<string>()
            };
            var response = _iSizeMasterRepositories.GetAll();
            if (response != null)
            {
                res.IsSuccess = true;
                res.Data = _mapper.Map<IEnumerable<DBSizeMaster>, IEnumerable<SizeMasterResponse>>(response);
            }
            else
            {
                res.Errors.Add("Something went wrong !!");
            }
            return res;
        }
    }
}
