﻿using AutoMapper;
using BusinessEntities.Mall.Common;
using BusinessEntities.Mall.RequestDto;
using BusinessEntities.Mall.ResponseDto;
using BusinessService.Interface;
using Repositories.Interface;
using Repositories.Mall;
using System.Collections.Generic;

namespace BusinessService.Implementation
{
    public class TagMasterService : ITagMasterService
    {
        private IMapper _mapper;
        private readonly ITagMasterRepositories _iTagMasterRepositories;

        public TagMasterService(ITagMasterRepositories repository, IMapper mapper)
        {
            _iTagMasterRepositories = repository;
            _mapper = mapper;
        }

        public ResultDto<long> Add(TagMasterRequest viewModel)
        {
            var res = new ResultDto<long>()
            {
                IsSuccess = false,
                Data = 0,
                Errors = new List<string>()
            };

            var response = _iTagMasterRepositories.Add(viewModel);
            if (response > 0)
            {
                res.IsSuccess = true;
                res.Data = response;
            }
            else
            {
                res.Errors.Add("Tag Name Already Exists !!");
            }
            return res;
        }
        public ResultDto<long> Update(TagMasterRequest viewModel)
        {
            var res = new ResultDto<long>()
            {
                IsSuccess = false,
                Data = 0,
                Errors = new List<string>()
            };

            var response = _iTagMasterRepositories.Update(viewModel);
            if (response > 0)
            {
                res.IsSuccess = true;
                res.Data = response;
            }
            else
            {
                res.Errors.Add("Tag Name Already Exists !!");
            }
            return res;
        }
        public ResultDto<long> Delete(long Id)
        {
            var res = new ResultDto<long>()
            {
                IsSuccess = false,
                Data = 0,
                Errors = new List<string>()
            };

            var response = _iTagMasterRepositories.Delete(Id);
            if (response > 0)
            {
                res.IsSuccess = true;
                res.Data = response;
            }
            else
            {
                res.Errors.Add("Record Not Found !!");
            }
            return res;
        }
        public ResultDto<TagMasterResponse> GetbyId(long Id)
        {
            var res = new ResultDto<TagMasterResponse>()
            {
                IsSuccess = false,
                Data = null,
                Errors = new List<string>()
            };
            var response = _iTagMasterRepositories.GetbyId(Id);
            if (response != null)
            {
                res.IsSuccess = true;
                res.Data = _mapper.Map<DBTagMaster, TagMasterResponse>(response);
            }
            else
            {
                res.Errors.Add("Something went wrong !!");
            }

            return res;
        }
        public ResultDto<IEnumerable<TagMasterResponse>> GetAll()
        {
            var res = new ResultDto<IEnumerable<TagMasterResponse>>()
            {
                IsSuccess = false,
                Data = null,
                Errors = new List<string>()
            };
            var response = _iTagMasterRepositories.GetAll();
            if (response != null)
            {
                res.IsSuccess = true;
                res.Data = _mapper.Map<IEnumerable<DBTagMaster>, IEnumerable<TagMasterResponse>>(response);
            }
            else
            {
                res.Errors.Add("Something went wrong !!");
            }
            return res;
        }
    }
}