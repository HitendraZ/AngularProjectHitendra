﻿using AutoMapper;
using BusinessEntities.Mall.Common;
using BusinessEntities.Mall.Master.RequestDto;
using BusinessEntities.Mall.Master.ResponseDto;
using BusinessService.Interface;
using Repositories.Interface;
using Repositories.Mall;
using System.Collections.Generic;

namespace BusinessService.Implementation
{
    public class BrandLogoService : IBrandLogoService
    {
        private readonly IBrandLogoRepository _iBrandLogoRepository;
        private IMapper _mapper;
        public BrandLogoService(IMapper mapper, IBrandLogoRepository repository)
        {
            _iBrandLogoRepository = repository;
            _mapper = mapper;
        }

        public ResultDto<long> Add(BrandLogoRequest viewModel)
        {
            var res = new ResultDto<long>()
            {
                IsSuccess = false,
                Data = 0,
                Errors = new List<string>()
            };
            var response = _iBrandLogoRepository.Add(viewModel);
            if (response == -1)
            {
                res.Errors.Add("Brand name allready exists");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data = response;
                return res;
            }
        }
        public ResultDto<long> Update(BrandLogoRequest viewModel)
        {
            var res = new ResultDto<long>()
            {
                IsSuccess = false,
                Data = 0,
                Errors = new List<string>()
            };
            var response = _iBrandLogoRepository.Update(viewModel);
            if (response == -1)
            {
                res.Errors.Add("Brand name allready exists");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data = response;
                return res;
            }
        }
        public ResultDto<long> Delete(int ID)
        {
            var res = new ResultDto<long>()
            {
                IsSuccess = false,
                Data = 0,
                Errors = new List<string>()
            };
            var response = _iBrandLogoRepository.Delete(ID);
            if (response == -1)
            {
                res.Errors.Add("Brand name not exists");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data = response;
                return res;
            }
        }
        public ResultDto<BrandLogoResponse> GetbyId(int Id)
        {
            var res = new ResultDto<BrandLogoResponse>()
            {
                IsSuccess = false,
                Data = null,
                Errors = new List<string>()
            };
            var response = _iBrandLogoRepository.GetbyId(Id);
            if (response == null)
            {
                res.Errors.Add("An Error Occured");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data = _mapper.Map<DBBrandLogo, BrandLogoResponse>(response);
                return res;
            }
        }
        public ResultDto<IEnumerable<BrandLogoResponse>> GetAll()
        {
            var res = new ResultDto<IEnumerable<BrandLogoResponse>>()
            {
                IsSuccess = false,
                Data = null,
                Errors = new List<string>()
            };
            var response = _iBrandLogoRepository.GetAll();
            if (response == null)
            {
                res.Errors.Add("An Error Occured");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data = _mapper.Map<IEnumerable<DBBrandLogo>, IEnumerable<BrandLogoResponse>>(response);
                return res;
            }
        }
    }
}

