﻿using AutoMapper;
using BusinessEntities.Mall.Common;
using BusinessEntities.Mall.Master.RequestDto;
using BusinessEntities.Mall.Master.ResponseDto;
using BusinessService.Interface;
using Repositories.Interface;
using Repositories.Mall;
using System.Collections.Generic;

namespace BusinessService.Implementation
{
    public class PaymentMasterService : IPaymentMasterService
    {
        private readonly IPaymentMasterRepository _iPaymentMasterRepository;
        private IMapper _mapper;
        public PaymentMasterService(IMapper mapper, IPaymentMasterRepository repository)
        {
            _iPaymentMasterRepository = repository;
            _mapper = mapper;
        }

        public ResultDto<BillingDetailsResponse> AddBillingDetails(BillingDetailsRequest viewModel)
        {
            var res = new ResultDto<BillingDetailsResponse>()
            {
                IsSuccess = false,
                Data = null,
                Errors = new List<string>()
            };
            var response = _iPaymentMasterRepository.AddBillingDetails(viewModel);
            if (response == null)
            {
                res.Errors.Add("Billing details allready exists");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data = _mapper.Map<DBBillingDetails, BillingDetailsResponse>(response);
                return res;
            }
        }
        public ResultDto<PurchaseItemResponse> AddPurchaseItem(PurchaseItemRequest viewModel)
        {
            var res = new ResultDto<PurchaseItemResponse>()
            {
                IsSuccess = false,
                Data = null,
                Errors = new List<string>()
            };
            var response = _iPaymentMasterRepository.AddPurchaseItem(viewModel);
            if (response == null)
            {
                res.Errors.Add("Billing details allready exists");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data = _mapper.Map<DBPurchaseItem, PurchaseItemResponse>(response);
                return res;
            }
        }
        public ResultDto<long> AddBillMaster(BillMasterRequest viewModel)
        {
            var res = new ResultDto<long>()
            {
                IsSuccess = false,
                Data = 0,
                Errors = new List<string>()
            };
            var response = _iPaymentMasterRepository.AddBillMaster(viewModel);
            if (response == 0)
            {
                res.Errors.Add("An error occured !!");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data = response;
                return res;
            }
        }
        public ResultDto<DoPaymentMasterResponse> AddPaymentMaster(DoPaymentMasterRequest viewModel)
        {
            var res = new ResultDto<DoPaymentMasterResponse>()
            {
                IsSuccess = false,
                Data = null,
                Errors = new List<string>()
            };
            var response = _iPaymentMasterRepository.AddPaymentMaster(viewModel);
            if (response == null)
            {
                res.Errors.Add("An error occured !!");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data = _mapper.Map<DBDoPaymentMaster, DoPaymentMasterResponse>(response);
                return res;
            }
        }
        public ResultDto<OnlinePaymentMasterResponse> SaveOnlinePayment(OnlinePaymentMasterRequest viewModel)
        {
            var res = new ResultDto<OnlinePaymentMasterResponse>()
            {
                IsSuccess = false,
                Data = null,
                Errors = new List<string>()
            };
            var response = _iPaymentMasterRepository.SaveOnlinePayment(viewModel);
            if (response == null)
            {
                res.Errors.Add("An error occured !!");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data = _mapper.Map<DBOnlinePaymentMaster, OnlinePaymentMasterResponse>(response);
                return res;
            }
        }
        //Report Section Here
        public ResultDto<IEnumerable<ReportManageOrderResponse>> GetReportManageOrder()
        {
            var res = new ResultDto<IEnumerable<ReportManageOrderResponse>>()
            {
                IsSuccess = false,
                Data = null,
                Errors = new List<string>()
            };
            var response = _iPaymentMasterRepository.GetReportManageOrder();
            if (response == null)
            {
                res.Errors.Add("An Error Occured");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data = _mapper.Map<IEnumerable<DBReportManageOrder>, IEnumerable<ReportManageOrderResponse>>(response);
                return res;
            }
        }
        public ResultDto<IEnumerable<ReportTransactionDetailsResponse>> GetReportTransactionDetails()
        {
            var res = new ResultDto<IEnumerable<ReportTransactionDetailsResponse>>()
            {
                IsSuccess = false,
                Data = null,
                Errors = new List<string>()
            };
            var response = _iPaymentMasterRepository.GetReportTransactionDetails();
            if (response == null)
            {
                res.Errors.Add("An Error Occured");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data = _mapper.Map<IEnumerable<DBReportTransactionDetails>, IEnumerable<ReportTransactionDetailsResponse>>(response);
                return res;
            }
        }
        public ResultDto<IEnumerable<ReportManageOrderResponse>> GetReportCashOnDelivery()
        {
            var res = new ResultDto<IEnumerable<ReportManageOrderResponse>>()
            {
                IsSuccess = false,
                Data = null,
                Errors = new List<string>()
            };
            var response = _iPaymentMasterRepository.GetReportCashOnDelivery();
            if (response == null)
            {
                res.Errors.Add("An Error Occured");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data = _mapper.Map<IEnumerable<DBReportManageOrder>, IEnumerable<ReportManageOrderResponse>>(response);
                return res;
            }
        }
        public ResultDto<IEnumerable<ReportManageOrderResponse>> GetReportInvoiceList()
        {
            var res = new ResultDto<IEnumerable<ReportManageOrderResponse>>()
            {
                IsSuccess = false,
                Data = null,
                Errors = new List<string>()
            };
            var response = _iPaymentMasterRepository.GetReportInvoiceList();
            if (response == null)
            {
                res.Errors.Add("An Error Occured");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data = _mapper.Map<IEnumerable<DBReportManageOrder>, IEnumerable<ReportManageOrderResponse>>(response);
                return res;
            }
        }
        public ResultDto<IEnumerable<ReportNetFigureResponse>> GetReportNetFigure()
        {
            var res = new ResultDto<IEnumerable<ReportNetFigureResponse>>()
            {
                IsSuccess = false,
                Data = null,
                Errors = new List<string>()
            };
            var response = _iPaymentMasterRepository.GetReportNetFigure();
            if (response == null)
            {
                res.Errors.Add("An Error Occured");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data = _mapper.Map<IEnumerable<DBReportNetFigure>, IEnumerable<ReportNetFigureResponse>>(response);
                return res;
            }
        }
        public ResultDto<IEnumerable<ChartOrderStatusResponse>> GetChartOrderStatus()
        {
            var res = new ResultDto<IEnumerable<ChartOrderStatusResponse>>()
            {
                IsSuccess = false,
                Data = null,
                Errors = new List<string>()
            };
            var response = _iPaymentMasterRepository.GetChartOrderStatus();
            if (response == null)
            {
                res.Errors.Add("An Error Occured");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data = _mapper.Map<IEnumerable<DBChartOrderStatus>, IEnumerable<ChartOrderStatusResponse>>(response);
                return res;
            }
        }
        public ResultDto<IEnumerable<ChartSalesDataPaymentTypeWiseResponse>> GetChartSalesDataPaymentTypeWise()
        {
            var res = new ResultDto<IEnumerable<ChartSalesDataPaymentTypeWiseResponse>>()
            {
                IsSuccess = false,
                Data = null,
                Errors = new List<string>()
            };
            var response = _iPaymentMasterRepository.GetChartSalesDataPaymentTypeWise();
            if (response == null)
            {
                res.Errors.Add("An Error Occured");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data = _mapper.Map<IEnumerable<DBChartSalesDataPaymentTypeWise>, IEnumerable<ChartSalesDataPaymentTypeWiseResponse>>(response);
                return res;
            }
        }
        public ResultDto<IEnumerable<ChartUserGrowthResponse>> GetChartUserGrowth()
        {
            var res = new ResultDto<IEnumerable<ChartUserGrowthResponse>>()
            {
                IsSuccess = false,
                Data = null,
                Errors = new List<string>()
            };
            var response = _iPaymentMasterRepository.GetChartUserGrowth();
            if (response == null)
            {
                res.Errors.Add("An Error Occured");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data = _mapper.Map<IEnumerable<DBChartUserGrowth>, IEnumerable<ChartUserGrowthResponse>>(response);
                return res;
            }
        }
    }
}
