﻿using AutoMapper;
using BusinessEntities.Mall.Common;
using BusinessEntities.Mall.Master.RequestDto;
using BusinessEntities.Mall.Master.ResponseDto;
using BusinessService.Interface;
using Repositories.Interface;
using Repositories.Mall;
using System.Collections.Generic;

namespace BusinessService.Implementation
{
   public class ProductMasterService : IProductMasterService
    {
        private readonly IProductMasterRepository _iProductMasterRepository;
        private IMapper _mapper;
        public ProductMasterService(IMapper mapper, IProductMasterRepository repository)
        {
            _iProductMasterRepository = repository;
            _mapper = mapper;
        }

        public ResultDto<ProductMasterResponse> Add(ProductMasterRequest viewModel)
        {
            var res = new ResultDto<ProductMasterResponse>()
            {
                IsSuccess = false,
                Data = null,
                Errors = new List<string>()
            };
            var response = _iProductMasterRepository.Add(viewModel);
            if (response == null)
            {
                res.Errors.Add("Item name allready exists");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data = _mapper.Map<DBProductMaster, ProductMasterResponse>(response);
                return res;
            }
        }
        public ResultDto<ProductMasterResponse> Update(ProductMasterRequest viewModel)
        {
            var res = new ResultDto<ProductMasterResponse>()
            {
                IsSuccess = false,
                Data = null,
                Errors = new List<string>()
            };
            var response = _iProductMasterRepository.Update(viewModel);
            if (response == null)
            {
                res.Errors.Add("Item name not exists");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data = _mapper.Map<DBProductMaster, ProductMasterResponse>(response);
                return res;
            }
        }
        public ResultDto<long> AddImageMapping(ProductPictureMappingRequest viewModel)
        {
            var res = new ResultDto<long>()
            {
                IsSuccess = false,
                Data = 0,
                Errors = new List<string>()
            };
            var response = _iProductMasterRepository.AddImageMapping(viewModel);
            if (response == -1)
            {
                res.Errors.Add("Item name allready exists");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data = response;
                return res;
            }
        }
        public ResultDto<long> Delete(int ID)
        {
            var res = new ResultDto<long>()
            {
                IsSuccess = false,
                Data = 0,
                Errors = new List<string>()
            };
            var response = _iProductMasterRepository.Delete(ID);
            if (response == -1)
            {
                res.Errors.Add("Item name not exists");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data = response;
                return res;
            }
        }
        public ResultDto<ProductMasterResponse> GetbyId(int Id)
        {
            var res = new ResultDto<ProductMasterResponse>()
            {
                IsSuccess = false,
                Data = null,
                Errors = new List<string>()
            };
            var response = _iProductMasterRepository.GetbyId(Id);
            if (response == null)
            {
                res.Errors.Add("An Error Occured");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data = _mapper.Map<DBProductMaster, ProductMasterResponse>(response);
                return res;
            }
        }
        public ResultDto<IEnumerable<ProductListPicturesResponse>> GetProductPicturebyId(int Id)
        {
            var res = new ResultDto<IEnumerable<ProductListPicturesResponse>>()
            {
                IsSuccess = false,
                Data = null,
                Errors = new List<string>()
            };
            var response = _iProductMasterRepository.GetProductPicturebyId(Id);
            if (response == null)
            {
                res.Errors.Add("An Error Occured");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data = _mapper.Map<IEnumerable<DBProductListPictures>, IEnumerable<ProductListPicturesResponse>>(response);
                return res;
            }
        }
        public ResultDto<IEnumerable<ProductMasterResponse>> GetAll()
        {
            var res = new ResultDto<IEnumerable<ProductMasterResponse>>()
            {
                IsSuccess = false,
                Data = null,
                Errors = new List<string>()
            };
            var response = _iProductMasterRepository.GetAll();
            if (response == null)
            {
                res.Errors.Add("An Error Occured");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data = _mapper.Map<IEnumerable<DBProductMaster>, IEnumerable<ProductMasterResponse>>(response);
                return res;
            }
        }
        //for forntend data
        
        //public ResultDto<IEnumerable<ProductListResponse>> GetProductList()
        //{
        //    var res = new ResultDto<IEnumerable<ProductListResponse>>()
        //    {
        //        IsSuccess = false,
        //        Data = null,
        //        Errors = new List<string>()
        //    };
        //    var response = _iProductMasterRepository.GetProductList();
        //    if (response == null)
        //    {
        //        res.Errors.Add("An Error Occured");
        //        return res;
        //    }
        //    else
        //    {
        //        res.IsSuccess = true;
        //        res.Data = _mapper.Map<IEnumerable<DBProductList>, IEnumerable<ProductListResponse>>(response);
        //        return res;
        //    }
        //}

        public IEnumerable<ProductListResponse> GetProductList()
        {
            var response = _iProductMasterRepository.GetProductList();
            var res = _mapper.Map<IEnumerable<DBProductList>, IEnumerable<ProductListResponse>>(response);
            return res;
        }
        public ResultDto<IEnumerable<ProductListColorsResponse>> GetProductcolorsList()
        {
            var res = new ResultDto<IEnumerable<ProductListColorsResponse>>()
            {
                IsSuccess = false,
                Data = null,
                Errors = new List<string>()
            };
            var response = _iProductMasterRepository.GetProductcolorsList();
            if (response == null)
            {
                res.Errors.Add("An Error Occured");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data = _mapper.Map<IEnumerable<DBProductListColors>, IEnumerable<ProductListColorsResponse>>(response);
                return res;
            }
        }
        public ResultDto<IEnumerable<ProductListPicturesResponse>> GetProductPicturesList()
        {
            var res = new ResultDto<IEnumerable<ProductListPicturesResponse>>()
            {
                IsSuccess = false,
                Data = null,
                Errors = new List<string>()
            };
            var response = _iProductMasterRepository.GetProductPicturesList();
            if (response == null)
            {
                res.Errors.Add("An Error Occured");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data = _mapper.Map<IEnumerable<DBProductListPictures>, IEnumerable<ProductListPicturesResponse>>(response);
                return res;
            }
        }
        public ResultDto<IEnumerable<ProductListSizesResponse>> GetProductSizesList()
        {
            var res = new ResultDto<IEnumerable<ProductListSizesResponse>>()
            {
                IsSuccess = false,
                Data = null,
                Errors = new List<string>()
            };
            var response = _iProductMasterRepository.GetProductSizesList();
            if (response == null)
            {
                res.Errors.Add("An Error Occured");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data = _mapper.Map<IEnumerable<DBProductListSizes>, IEnumerable<ProductListSizesResponse>>(response);
                return res;
            }
        }
        public ResultDto<IEnumerable<ProductListTagsResponse>> GetProductTagsList()
        {
            var res = new ResultDto<IEnumerable<ProductListTagsResponse>>()
            {
                IsSuccess = false,
                Data = null,
                Errors = new List<string>()
            };
            var response = _iProductMasterRepository.GetProductTagsList();
            if (response == null)
            {
                res.Errors.Add("An Error Occured");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data = _mapper.Map<IEnumerable<DBProductListTags>, IEnumerable<ProductListTagsResponse>>(response);
                return res;
            }
        }
        public ResultDto<IEnumerable<ProductListVariantsResponse>> GetProductVariantsList()
        {
            var res = new ResultDto<IEnumerable<ProductListVariantsResponse>>()
            {
                IsSuccess = false,
                Data = null,
                Errors = new List<string>()
            };
            var response = _iProductMasterRepository.GetProductVariantsList();
            if (response == null)
            {
                res.Errors.Add("An Error Occured");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data = _mapper.Map<IEnumerable<DBProductListVariants>, IEnumerable<ProductListVariantsResponse>>(response);
                return res;
            }
        }
    }
}
