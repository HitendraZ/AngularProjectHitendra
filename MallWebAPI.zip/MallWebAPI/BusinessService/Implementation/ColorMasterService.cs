﻿using AutoMapper;
using BusinessEntities.Mall.Common;
using BusinessEntities.Mall.RequestDto;
using BusinessEntities.Mall.ResponseDto;
using BusinessService.Interface;
using Repositories.Interface;
using Repositories.Mall;
using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessService.Implementation
{
   public class ColorMasterService : IColorMasterService
    {
        private IMapper _mapper;
        private readonly IColorMasterRepositories _iColorMasterRepositories;

        public ColorMasterService(IColorMasterRepositories repository, IMapper mapper)
        {
            _iColorMasterRepositories = repository;
            _mapper = mapper;
        }

        public ResultDto<long> Add(ColorMasterRequest viewModel)
        {
            var res = new ResultDto<long>()
            {
                IsSuccess = false,
                Data = 0,
                Errors = new List<string>()
            };

            var response = _iColorMasterRepositories.Add(viewModel);
            if (response > 0)
            {
                res.IsSuccess = true;
                res.Data = response;
            }
            else
            {
                res.Errors.Add("Color Name Already Exists !!");
            }
            return res;
        }
        public ResultDto<long> Update(ColorMasterRequest viewModel)
        {
            var res = new ResultDto<long>()
            {
                IsSuccess = false,
                Data = 0,
                Errors = new List<string>()
            };

            var response = _iColorMasterRepositories.Update(viewModel);
            if (response > 0)
            {
                res.IsSuccess = true;
                res.Data = response;
            }
            else
            {
                res.Errors.Add("Color Name Already Exists !!");
            }
            return res;
        }
        public ResultDto<long> Delete(long Id)
        {
            var res = new ResultDto<long>()
            {
                IsSuccess = false,
                Data = 0,
                Errors = new List<string>()
            };

            var response = _iColorMasterRepositories.Delete(Id);
            if (response > 0)
            {
                res.IsSuccess = true;
                res.Data = response;
            }
            else
            {
                res.Errors.Add("Record not exists !!");
            }
            return res;
        }
        public ResultDto<ColorMasterResponse> GetbyId(long Id)
        {
            var res = new ResultDto<ColorMasterResponse>()
            {
                IsSuccess = false,
                Data = null,
                Errors = new List<string>()
            };
            var response = _iColorMasterRepositories.GetbyId(Id);

            if (response != null)
            {
                res.IsSuccess = true;
                res.Data = _mapper.Map<DBColorMaster, ColorMasterResponse>(response);
            }
            else
            {
                res.Errors.Add("Something went wrong !!");
            }
            return res;
        }
        public ResultDto<IEnumerable<ColorMasterResponse>> GetAll()
        {
            var res = new ResultDto<IEnumerable<ColorMasterResponse>>()
            {
                IsSuccess = false,
                Data = null,
                Errors = new List<string>()
            };
            var response = _iColorMasterRepositories.GetAll();
            if (response != null)
            {
                res.IsSuccess = true;
                res.Data = _mapper.Map<IEnumerable<DBColorMaster>, IEnumerable<ColorMasterResponse>>(response);
            }
            else
            {
                res.Errors.Add("Something went wrong !!");
            }
            return res;
        }
    }
}
