﻿using AutoMapper;
using BusinessEntities.Mall.Common;
using BusinessEntities.Mall.Master.RequestDto;
using BusinessEntities.Mall.Master.ResponseDto;
using BusinessService.Interface;
using Repositories.Interface;
using Repositories.Mall;
using System.Collections.Generic;

namespace BusinessService.Implementation
{
    public class UserMasterService : IUserMasterService
    {
        private readonly IUserMasterRepository _iUserRepository;
        private IMapper _mapper;
        public UserMasterService(IMapper mapper, IUserMasterRepository repository)
        {
            _iUserRepository = repository;
            _mapper = mapper;
        }

        public ResultDto<long> Add(UserMasterRequest viewModel)
        {
            var res = new ResultDto<long>()
            {
                IsSuccess = false,
                Data = 0,
                Errors = new List<string>()
            };
            var response = _iUserRepository.Add(viewModel);
            if (response == 0)
            {
                res.Errors.Add("An Error Occured");
                return res;
            }
            if (response == -1)
            {
                res.Errors.Add("Email Is already exists !!");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data = response;
                return res;
            }
        }
        public ResultDto<long> UpdateUser(UserMasterRequest viewModel)
        {
            var res = new ResultDto<long>()
            {
                IsSuccess = false,
                Data = 0,
                Errors = new List<string>()
            };
            var response = _iUserRepository.UpdateUser(viewModel);
            if (response == 0)
            {
                res.Errors.Add("An Error Occured");
                return res;
            }
            if (response == -1)
            {
                res.Errors.Add("Email Is already exists !!");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data = response;
                return res;
            }
        }
        public ResultDto<long> DeleteUser(int ID)
        {
            var res = new ResultDto<long>()
            {
                IsSuccess = false,
                Data = 0,
                Errors = new List<string>()
            };
            var response = _iUserRepository.DeleteUser(ID);
            if (response == 0)
            {
                res.Errors.Add("An Error Occured");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data = response;
                return res;
            }
        }
        public ResultDto<UserMasterResponse> GetUserbyId(int Id)
        {
            var res = new ResultDto<UserMasterResponse>()
            {
                IsSuccess = false,
                Data = null,
                Errors = new List<string>()
            };
            var response = _iUserRepository.GetUserbyId(Id);
            if(response==null)
            {
                res.Errors.Add("An Error Occured");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data= _mapper.Map<DBUserMaster, UserMasterResponse>(response);
                return res;
            }
        }
        public ResultDto<IEnumerable<UserMasterResponse>> GetAllUser()
        {
            var res = new ResultDto<IEnumerable<UserMasterResponse>>()
            {
                IsSuccess = false,
                Data = null,
                Errors = new List<string>()
            };
            var response = _iUserRepository.GetAllUser();
            if (response == null)
            {
                res.Errors.Add("An Error Occured");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data = _mapper.Map<IEnumerable<DBUserMaster>, IEnumerable<UserMasterResponse>>(response);
                return res;
            }
        }
        public ResultDto<LoginResponse> Login(LoginRequest viewModel)
        {
            var res = new ResultDto<LoginResponse>()
            {
                IsSuccess = false,
                Data = null,
                Errors = new List<string>()
            };
            var response = _iUserRepository.Login(viewModel);
            if (response == null)
            {
                res.Errors.Add("An Error Occured");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data = _mapper.Map<DBLogin, LoginResponse>(response);
                return res;
            }
        }
    }
}
