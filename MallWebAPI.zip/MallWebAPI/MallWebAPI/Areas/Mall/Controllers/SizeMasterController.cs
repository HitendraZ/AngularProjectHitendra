﻿using BusinessEntities.Mall.Master.RequestDto;
using BusinessEntities.Mall.RequestDto;
using BusinessService.Interface;
using MallWebAPI.Filter;
using Microsoft.AspNetCore.Mvc;

namespace MallWebAPI.Areas.Mall.Controllers
{
    [ServiceFilter(typeof(DblExcptionFilter))]
    [Produces("application/json")]
    [Area("Mall")]
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class SizeMasterController : ControllerBase
    {
        private readonly ISizeMasterService _iSizeMasterService;
        public SizeMasterController(ISizeMasterService iSizeMasterService)
        {
            _iSizeMasterService = iSizeMasterService;
        }

        [HttpGet]
        [ActionName("GetAll")]
        public IActionResult GetAll()
        {
            var res = _iSizeMasterService.GetAll();
            return Ok(res);
        }

        [HttpGet("{Id}")]
        [ActionName("GetbyId")]
        public IActionResult GetById(long Id)
        {
            var res = _iSizeMasterService.GetbyId(Id);
            return Ok(res);
        }

        [HttpPost]
        [ActionName("Save")]
        public IActionResult Post(SizeMasterRequest viewModel)
        {
            var res = _iSizeMasterService.Add(viewModel);
            return Ok(res);
        }

        [HttpPost]
        [ActionName("Update")]
        public IActionResult Update(SizeMasterRequest viewModel)
        {
            var res = _iSizeMasterService.Update(viewModel);
            return Ok(res);
        }


        [HttpPost()]
        [ActionName("Delete")]
        public IActionResult Delete([FromBody]Value viewModel)
        {
            var res = _iSizeMasterService.Delete(viewModel.Id);
            return Ok(res);
        }
    }
}