﻿using BusinessEntities.Mall.Master.RequestDto;
using BusinessEntities.Mall.RequestDto;
using BusinessService.Interface;
using MallWebAPI.Filter;
using Microsoft.AspNetCore.Mvc;

namespace MallWebAPI.Areas.Mall.Controllers
{
    [ServiceFilter(typeof(DblExcptionFilter))]
    [Produces("application/json")]
    [Area("Mall")]
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class TagMasterController : ControllerBase
    {
        private readonly ITagMasterService _iTagMasterService;
        public TagMasterController(ITagMasterService iTagMasterService)
        {
            _iTagMasterService = iTagMasterService;
        }

        [HttpGet]
        [ActionName("GetAll")]
        public IActionResult GetAll()
        {
            var res = _iTagMasterService.GetAll();
            return Ok(res);
        }

        [HttpGet("{Id}")]
        [ActionName("GetbyId")]
        public IActionResult GetById(long Id)
        {
            var res = _iTagMasterService.GetbyId(Id);
            return Ok(res);
        }

        [HttpPost]
        [ActionName("Save")]
        public IActionResult Post(TagMasterRequest viewModel)
        {
            var res = _iTagMasterService.Add(viewModel);
            return Ok(res);
        }

        [HttpPost]
        [ActionName("Update")]
        public IActionResult Update(TagMasterRequest viewModel)
        {
            var res = _iTagMasterService.Update(viewModel);
            return Ok(res);
        }


        [HttpPost()]
        [ActionName("Delete")]
        public IActionResult Delete([FromBody]Value viewModel)
        {
            var res = _iTagMasterService.Delete(viewModel.Id);
            return Ok(res);
        }
    }
}