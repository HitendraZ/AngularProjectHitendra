﻿using System;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using BusinessEntities.Mall.Master.RequestDto;
using BusinessService.Interface;
using MallWebAPI.Filter;
using MallWebAPI.Helpers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;

namespace API.Areas.Mall.Controllers
{
    [Authorize]
    [ServiceFilter(typeof(DblExcptionFilter))]
    [Area("Mall")]
    [Produces("application/json")]
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class UserMasterController : ControllerBase
    {
        private readonly IUserMasterService _iUserService;
        private readonly AppSettings _appSettings;

        public UserMasterController(IUserMasterService iUserService, IOptions<AppSettings> appSettings)
        {
            _iUserService = iUserService;
            _appSettings = appSettings.Value;
        }

        [HttpGet]
        [ActionName("GetAll")]
        public IActionResult GetAllUser()
        {
            var res = _iUserService.GetAllUser();
            if(res.IsSuccess)
            {
                return Ok(res);
            }
            return NotFound(res);
        }

        [HttpGet("{Id}")]
        [ActionName("GetbyId")]
        public IActionResult GetAllUser(int Id)
        {
            var res = _iUserService.GetUserbyId(Id);
            if (res.IsSuccess)
            {
                return Ok(res);
            }
            return NotFound(res);
        }

        [AllowAnonymous]
        [HttpPost]
        [ActionName("Save")]
        public IActionResult Post([FromBody]UserMasterRequest viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState.Values.ToArray());
            }

            var res = _iUserService.Add(viewModel);
            return Ok(res);
        }

        [HttpPost]
        [ActionName("Update")]
        public IActionResult UpdateUser([FromBody]UserMasterRequest viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState.Values.ToArray());
            }
            var res = _iUserService.UpdateUser(viewModel);
            return Ok(res);
        }

        [HttpPost]
        [ActionName("Delete")]
        public IActionResult DeleteUser([FromBody]Value viewModel)
        {
            var res = _iUserService.DeleteUser(viewModel.Id);
            return Ok(res); 
        }

        [AllowAnonymous]
        [HttpPost]
        [ActionName("Login")]
        public IActionResult Login([FromBody]LoginRequest viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState.Values.ToArray());
            }

            var res = _iUserService.Login(viewModel);

            if (res.Data != null)
            {
                // authentication successful so generate jwt token
                var tokenHandler = new JwtSecurityTokenHandler();
                var key = Encoding.ASCII.GetBytes(_appSettings.Secret);
                var tokenDescriptor = new SecurityTokenDescriptor
                {
                    Subject = new ClaimsIdentity(new Claim[]
                {
                new Claim(ClaimTypes.Name, res.Data.Id.ToString())
                }),
                    Expires = DateTime.UtcNow.AddDays(7),
                    SigningCredentials = new SigningCredentials(new
               SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
                };
                var token = tokenHandler.CreateToken(tokenDescriptor);
                res.Data.Token = tokenHandler.WriteToken(token);
            }
            return Ok(res);
        }
    }
}