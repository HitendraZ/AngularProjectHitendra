﻿using BusinessEntities.Mall.Master.RequestDto;
using BusinessEntities.Mall.RequestDto;
using BusinessService.Interface;
using MallWebAPI.Filter;
using Microsoft.AspNetCore.Mvc;

namespace MallWebAPI.Areas.Mall.Controllers
{
    [ServiceFilter(typeof(DblExcptionFilter))]
    [Produces("application/json")]
    [Area("Mall")]
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class ColorMasterController : ControllerBase
    {
        private readonly IColorMasterService _iColorMasterService;
        public ColorMasterController(IColorMasterService iColorMasterService)
        {
            _iColorMasterService = iColorMasterService;
        }

        [HttpGet]
        [ActionName("GetAll")]
        public IActionResult GetAll()
        {
            var res = _iColorMasterService.GetAll();
            return Ok(res);
        }

        [HttpGet("{Id}")]
        [ActionName("GetbyId")]
        public IActionResult GetById(long Id)
        {
            var res = _iColorMasterService.GetbyId(Id);
            return Ok(res);
        }

        [HttpPost]
        [ActionName("Save")]
        public IActionResult Post(ColorMasterRequest viewModel)
        {
            var res = _iColorMasterService.Add(viewModel);
            return Ok(res);
        }

        [HttpPost]
        [ActionName("Update")]
        public IActionResult Update(ColorMasterRequest viewModel)
        {
            var res = _iColorMasterService.Update(viewModel);
            return Ok(res);
        }


        [HttpPost]
        [ActionName("Delete")]
        public IActionResult Delete(Value model)
        {
            var res = _iColorMasterService.Delete(model.Id);
            return Ok(res);
        }
    }
}