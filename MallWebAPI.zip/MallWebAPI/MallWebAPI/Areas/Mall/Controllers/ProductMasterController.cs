﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using BusinessEntities.Mall.Master.RequestDto;
using BusinessEntities.Mall.Master.ResponseDto;
using BusinessService.Interface;
using MallWebAPI.Filter;
using Microsoft.AspNetCore.Mvc;

namespace API.Areas.Mall.Controllers
{
    [ServiceFilter(typeof(DblExcptionFilter))]
    [Area("Mall")]
    [Produces("application/json")]
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class ProductMasterController : ControllerBase
    {
        private readonly IProductMasterService _iProductMasterService;

        public ProductMasterController(IProductMasterService iProductMasterService)
        {
            _iProductMasterService = iProductMasterService;
        }

        [HttpPost, DisableRequestSizeLimit]
        [ActionName("Save")]
        public IActionResult UploadImage()
        {
            ProductMasterRequest viewModel = new ProductMasterRequest
            {
                Name = Request.Form["Name"][0],
                Title = Request.Form["Title"][0],
                Code = Request.Form["Code"][0],
                Price = Convert.ToDecimal(Request.Form["Price"][0]),
                SalePrice = Convert.ToDecimal(Request.Form["SalePrice"][0]),
                ShortDetails = Request.Form["ShortDetails"][0],
                Description = Request.Form["Description"][0],
                Quantity = Convert.ToInt16(Request.Form["Quantity"][0]),
                Discount = Convert.ToInt16(Request.Form["Discount"][0]),
                IsNew = Convert.ToInt16(Request.Form["IsNew"][0] == "true" ? 1 : 0),
                IsSale = Convert.ToInt16(Request.Form["IsSale"][0] == "true" ? 1 : 0),
                CategoryId = Convert.ToInt16(Request.Form["CategoryId"][0]),
                ColorId = Convert.ToInt16(Request.Form["ColorId"][0]),
                SizeId = Convert.ToInt16(Request.Form["SizeId"][0]),
                TagId = Convert.ToInt16(Request.Form["TagId"][0])
            };
            var res = _iProductMasterService.Add(viewModel);


            var folderName = "Images";
            var pathToSave = Path.Combine(Directory.GetCurrentDirectory(), folderName);
            var files = Request.Form.Files;
            int count = 1;
            foreach (var Image in files)
            {
                if (Image != null && Image.Length > 0)
                {
                    var postedFile = Image;
                    if (postedFile.Length > 0)
                    {
                        var fileName = ContentDispositionHeaderValue.Parse(postedFile.ContentDisposition).FileName.Trim('"');
                        var fullPath = Path.Combine(pathToSave, fileName);
                        var dbPath = Path.Combine(folderName, fileName);
                        using (var stream = new FileStream(fullPath, FileMode.Create))
                        {
                            postedFile.CopyTo(stream);
                        }

                        ProductPictureMappingRequest vm = new ProductPictureMappingRequest
                        {
                            ProductId = res.Data.Id,
                            PictureName = fileName,
                            PicturePath = fileName,
                            IsDelete = count
                        };
                        var res1 = _iProductMasterService.AddImageMapping(vm);
                        count++;
                    }
                }
            }
            return Ok(res);
        }

        [HttpPost, DisableRequestSizeLimit]
        [ActionName("Update")]
        public IActionResult UpdateProduct()
        {
            ProductMasterRequest viewModel = new ProductMasterRequest
            {
                Id = Convert.ToInt16(Request.Form["Id"][0]),
                Name = Request.Form["Name"][0],
                Title = Request.Form["Title"][0],
                Code = Request.Form["Code"][0],
                Price = Convert.ToDecimal(Request.Form["Price"][0]),
                SalePrice = Convert.ToDecimal(Request.Form["SalePrice"][0]),
                ShortDetails = Request.Form["ShortDetails"][0],
                Description = Request.Form["Description"][0],
                Quantity = Convert.ToInt16(Request.Form["Quantity"][0]),
                Discount = Convert.ToInt16(Request.Form["Discount"][0]),
                IsNew = Convert.ToInt16(Request.Form["IsNew"][0] == "true" ? 1 : 0),
                IsSale = Convert.ToInt16(Request.Form["IsSale"][0] == "true" ? 1 : 0),
                CategoryId = Convert.ToInt16(Request.Form["CategoryId"][0]),
                ColorId = Convert.ToInt16(Request.Form["ColorId"][0]),
                SizeId = Convert.ToInt16(Request.Form["SizeId"][0]),
                TagId = Convert.ToInt16(Request.Form["TagId"][0])
            };
            var res = _iProductMasterService.Update(viewModel);


            var folderName = "Images";
            var pathToSave = Path.Combine(Directory.GetCurrentDirectory(), folderName);
            var files = Request.Form.Files;
            int count = 1;
            foreach (var Image in files)
            {
                if (Image != null && Image.Length > 0)
                {
                    var postedFile = Image;
                    if (postedFile.Length > 0)
                    {
                        var fileName = ContentDispositionHeaderValue.Parse(postedFile.ContentDisposition).FileName.Trim('"');
                        var fullPath = Path.Combine(pathToSave, fileName);
                        var dbPath = Path.Combine(folderName, fileName);
                        using (var stream = new FileStream(fullPath, FileMode.Create))
                        {
                            postedFile.CopyTo(stream);
                        }

                        ProductPictureMappingRequest vm = new ProductPictureMappingRequest
                        {
                            ProductId = res.Data.Id,
                            PictureName = fileName,
                            PicturePath = fileName,
                            IsDelete = count
                        };
                        var res1 = _iProductMasterService.AddImageMapping(vm);
                        count++;
                    }
                }
            }
            return Ok(res);
        }

        [HttpGet]
        [ActionName("GetAll")]
        public IActionResult GetAll()
        {
            var res = _iProductMasterService.GetAll();
            if (res.IsSuccess)
            {
                return Ok(res);
            }
            return NotFound(res);
        }

        [HttpGet("{Id}")]
        [ActionName("GetbyId")]
        public IActionResult GetbyId(int Id)
        {
            var res = _iProductMasterService.GetbyId(Id);
            if (res.IsSuccess)
            {
                return Ok(res);
            }
            return NotFound(res);
        }

        [HttpGet("{Id}")]
        [ActionName("GetProductPicturebyId")]
        public IActionResult GetProductPicturebyId(int Id)
        {
            var res = _iProductMasterService.GetProductPicturebyId(Id);
            if (res.IsSuccess)
            {
                return Ok(res);
            }
            return NotFound(res);
        }

        [HttpPost]
        [ActionName("Delete")]
        public IActionResult Delete([FromBody]Value viewModel)
        {
            var res = _iProductMasterService.Delete(viewModel.Id);
            return Ok(res);
        }

        [HttpGet]
        [ActionName("GetProductList")]
        public IActionResult GetProductList()
        {
            var res = _iProductMasterService.GetProductList();
            var resColor = _iProductMasterService.GetProductcolorsList();
            var resSize = _iProductMasterService.GetProductSizesList();
            var resTag = _iProductMasterService.GetProductTagsList();
            var resPicture = _iProductMasterService.GetProductPicturesList();
            var resVariant = _iProductMasterService.GetProductVariantsList();

            List<string> lstList;
            List<Variant> ProductListVariants;

            List<ProductListColorsResponse> lstProductListColors;
            List<ProductListSizesResponse> lstProductListSizes;
            List<ProductListTagsResponse> lstProductListTags;
            List<ProductListPicturesResponse> lstProductListPictures;
            List<ProductListVariantsResponse> lstProductListVariants;
            foreach (var row in res)
            {
                //For Colors
                lstList = new List<string>();
                lstProductListColors = resColor.Data.ToList();
                foreach (var color in lstProductListColors.FindAll(o => o.ProductId == row.id))
                {
                    lstList.Add(color.Name);
                }
                row.colors = lstList;

                //For Sizes
                lstList = new List<string>();
                lstProductListSizes = resSize.Data.ToList();
                foreach (var size in lstProductListSizes.FindAll(o => o.ProductId == row.id))
                {
                    lstList.Add(size.Name);
                }
                row.size = lstList;

                //For Tags
                lstList = new List<string>();
                lstProductListTags = resTag.Data.ToList();
                foreach (var tag in lstProductListTags.FindAll(o => o.ProductId == row.id))
                {
                    lstList.Add(tag.Name);
                }
                row.tags = lstList;

                //For Pictures
                lstList = new List<string>();
                lstProductListPictures = resPicture.Data.ToList();
                foreach (var tag in lstProductListPictures.FindAll(o => o.ProductId == row.id))
                {
                    lstList.Add(tag.Name);
                }
                row.pictures = lstList;

                //For Variants
                ProductListVariants = new List<Variant>();
                lstProductListVariants = resVariant.Data.ToList();
                foreach (var variant in lstProductListVariants.FindAll(o => o.ProductId == row.id))
                {
                    var ObjVariantList = new Variant()
                    {
                        color = variant.color,
                        images = variant.images
                    };
                    ProductListVariants.Add(ObjVariantList);
                }
                row.variants = ProductListVariants;
            }
            return Ok(res);
        }
    }
}
