﻿using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;

namespace MallWebAPI.Extension
{
    public static class ServiceConfig
    {
        public static void AddExtensionServices(this IServiceCollection services)
        {
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new Swashbuckle.AspNetCore.Swagger.Info
                {
                    Version= "v1",
                    Title="Mall API",
                    Description="Shopping Application",
                    TermsOfService="....",
                    Contact = new Swashbuckle.AspNetCore.Swagger.Contact()
                    {
                        Name="Hitendra Z",
                        Email="hitendra2493@gmail.com",
                        Url=""
                    }
                });
            });
        }

        public static void AppConfigure(this IApplicationBuilder app)
        {
            app.UseCors("CorsPolicy");
            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json","Swagger API");
            });
        }

    }
}
