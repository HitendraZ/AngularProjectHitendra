﻿using BusinessEntities.Mall.Common;
using BusinessService.Interface;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Filters;
using System;

namespace MallWebAPI.Filter
{
    public class DblExcptionFilter : ExceptionFilterAttribute
    {
        private readonly IExceptionLogService _iExceptionLogService;
        private readonly IHostingEnvironment _iHostingEnvironment;

        public DblExcptionFilter(IExceptionLogService iExceptionLogService, IHostingEnvironment iHostingEnvironment)
        {
            _iExceptionLogService = iExceptionLogService;
            _iHostingEnvironment = iHostingEnvironment;
        }

        public override void OnException(ExceptionContext context)
        {
            if (_iHostingEnvironment.IsDevelopment())
            {
                LogEntryRequest log = new LogEntryRequest
                {
                    Date = DateTime.Now,
                    Message = context.Exception.Message,
                    Type = context.Exception.GetType().ToString(),
                    Source = context.Exception.Source,
                    RequestPath = context.HttpContext.Request.Path
                };

                _iExceptionLogService.Add(log);
            }
        }
    }
}
